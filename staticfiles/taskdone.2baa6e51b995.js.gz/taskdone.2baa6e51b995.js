
function myFunction() {

    if (request.method == "POST" ){
        category = request.POST["category_select"] 
        console.log(category) 
    }
    

    // var elements = document.getElementsByClassName('taskDone'), i, len;
    // document.getElementById("count").innerHTML= 2;
    // var clicked=0, unclicked=0;
    //     if (clicked==0){
    //         for (i = 0, len = elements.length; i < len; i++) {
    //             elements[i].style.textDecoration= "line-through";}
    //         clicked=1;
    //         console.log(clicked)
    //     }
    //     document.getElementById("demo").innerHTML = 5 + 6;
  }
